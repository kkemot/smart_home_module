#include "Arduino.h"
#include "ESPinfluxdb.h"


//#define DEBUG_PRINT // comment this line to disable debug print

#ifndef DEBUG_PRINT
#define DEBUG_PRINT(a)
#else
#define DEBUG_PRINT(a) (Serial.println(String(F("[Debug]: "))+(a)))
#define _DEBUG
#endif

Influxdb::Influxdb(const char *host, uint16_t port) {
        _port = String(port);
	_portNum = port;
        _host = String(host);
}

DB_RESPONSE Influxdb::configure(String db, String user, String password) {
        _db = db;
	_user = user;
	_password = password;
	DEBUG_PRINT("configure: " + _db +", " + _user + ", " + _password);

	//curl -XPOST 'http://localhost:8086/query?u=testuser&p=testpassword' --data-urlencode 'q=SHOW DATABASES'
	String uri = "/query?u=" + _user + "&p=" + _password;
	DEBUG_PRINT(uri);

	HTTPClient http;
	http.begin(_host, _portNum, uri);
	http.addHeader("Content-Type", "application/x-www-form-urlencoded");
	int httpResponse = http.POST("q=SHOW DATABASES");
	DEBUG_PRINT(httpResponse);

	// check connection to influxdb (v.1.5)
	if(httpResponse == HTTP_CODE_OK) {
		DEBUG_PRINT("Connection: Success");
	}
	else
	{
		DEBUG_PRINT("Connection: Failed");
		http.end();
		return DB_CONNECT_FAILED;
	}

	String responseString =  http.getString();
	DEBUG_PRINT(responseString);

	// check your databases ["your_DB"]
	if (responseString.indexOf("[\"" + _db + "\"]") > 0)
	{
		DEBUG_PRINT("Database: "+ _db + " exists.");
	}
	else
	{
		DEBUG_PRINT("Database: "+ _db + " doesnt exist or no access rights.");
		http.end();
		return DB_ERROR;
	}

	http.end();
	return DB_SUCCESS;
}

DB_RESPONSE Influxdb::configure(String db) {

        _db = db;
	_user = "";
	_password = "";
	DEBUG_PRINT("configure: " + _db);

	//curl -XPOST 'http://localhost:8086/query?u=testuser&p=testpassword' --data-urlencode 'q=SHOW DATABASES'
	String uri = "/query";
	DEBUG_PRINT(uri);

	HTTPClient http;
	http.begin(_host, _portNum, uri);
	http.addHeader("Content-Type", "application/x-www-form-urlencoded");
	int httpResponse = http.POST("q=SHOW DATABASES");
	DEBUG_PRINT(httpResponse);

	// check connection to influxdb (v.1.5)
	if(httpResponse == HTTP_CODE_OK) {
		DEBUG_PRINT("Connection: Success");
	}
	else
	{
		DEBUG_PRINT("Connection: Failed");
		http.end();
		return DB_CONNECT_FAILED;
	}

	String responseString =  http.getString();
	DEBUG_PRINT(responseString);

	// check your databases ["your_DB"]
	if (responseString.indexOf("[\"" + _db + "\"]") > 0)
	{
		DEBUG_PRINT("Database: "+ _db + " exists.");
	}
	else
	{
		DEBUG_PRINT("Database: "+ _db + " doesnt exist or no access rights.");
		http.end();
		return DB_ERROR;
	}

	http.end();
	return DB_SUCCESS;
}

DB_RESPONSE Influxdb::write(dbMeasurement data) {
        return write(data.postString());
}

DB_RESPONSE Influxdb::write(String data) {
	HTTPClient http;
	DEBUG_PRINT("write: " + data);
	//String _uri = "/write?db=testDB&u=" + _user+ "&p="+_password;
	String _uri = "/write?db=" + _db;
	if(_user != "" && _password != "") {
		_uri = _uri + "&u=" + _user+ "&p=" + _password;
	}

	http.begin(_host, 8086, _uri);
	http.addHeader("Content-Type", "text/plain");

	int httpResponseCode = http.POST(data);
	DEBUG_PRINT(httpResponseCode);


	if (httpResponseCode == HTTP_CODE_NO_CONTENT ) {
		String response = http.getString();
		http.end();
		return DB_SUCCESS;
	} else {
		DEBUG_PRINT("Error on sending POST:");
		DEBUG_PRINT(String(httpResponseCode));
		http.end();
		return DB_ERROR;
	}
}


/* -----------------------------------------------*/
//        Field object
/* -----------------------------------------------*/
dbMeasurement::dbMeasurement(String m) {
        measurement = m;
}

void dbMeasurement::empty() {
        _data = "";
        _tag = "";
}

void dbMeasurement::addTag(String key, String value) {
        _tag += "," + key + "=" + value;
}

void dbMeasurement::addField(String key, float value) {
        _data = (_data == "") ? (" ") : (_data += ",");
        _data += key + "=" + String(value);
}

void dbMeasurement::addField(String key, String value) {
        _data = (_data == "") ? (" ") : (_data += ",");
        _data += key + "=" + value;
}

String dbMeasurement::postString() {
        return measurement + _tag + _data;
}

