/* Influxdb library

   MIT license
   Written by HW Wong
 */

#ifndef INFLUXDB_H
#define INFLUXDB_H

#include <ESP8266HTTPClient.h>


enum DB_RESPONSE {DB_SUCCESS, DB_ERROR, DB_CONNECT_FAILED};

// Url encode function
String URLEncode(String msg);

class dbMeasurement
{
	public:
	dbMeasurement(String m);
	String measurement;

	void addField(String key, float value);
	void addField(String key, String value);
	void addTag(String key, String value);
	String postString(void);
	void empty();

	private:
	String _data;
	String _tag;
};

class Influxdb
{
	public:
	Influxdb(const char* host, uint16_t port);
	DB_RESPONSE configure(String db);
	DB_RESPONSE configure(String db, String user, String password);

	DB_RESPONSE write(dbMeasurement data);
	DB_RESPONSE write(String data);

	private:
	String _port;
	uint16_t _portNum;
	String _host;
	String _db;
	String _user;
	String _password;
};

#endif
