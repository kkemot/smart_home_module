This Arduino library is updated to support ESP32/ESP8266 and moved to https://github.com/hwwong/ESP_influxdb 


# ESP8266Influxdb
